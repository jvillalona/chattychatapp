//
//  MessageCell.swift
//  SmackJV
//
//  Created by Juan Villalona on 3/8/18.
//  Copyright © 2018 Juan Villalona. All rights reserved.
//

import UIKit

class MessageCell: UITableViewCell {

    // Outlets
    
    @IBOutlet weak var userimg: CircleImage!
    
    @IBOutlet weak var userNameLbl: UILabel!
    @IBOutlet weak var timeStampLbl: UILabel!
    
    @IBOutlet weak var messageBodyLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func configureCell(message: Message) {
        messageBodyLbl.text = message.message
        userNameLbl.text = message.userName
        userimg.image = UIImage(named: message.userAvatar)
        userimg.backgroundColor = UserDataService.instance.returnUIColor(component: message.userAvatarColor)
    }

}
