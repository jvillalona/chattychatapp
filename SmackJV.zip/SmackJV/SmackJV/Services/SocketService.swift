//
//  SocketService.swift
//  SmackJV
//
//  Created by Juan Villalona on 2/28/18.
//  Copyright © 2018 Juan Villalona. All rights reserved.
//

import UIKit
import SocketIO

//class SocketService: NSObject {
open class SocketService {
    
//    open class SocketConnection {
//
//        open static let `default` = SocketConnection()
//        private let manager: SocketManager
//        private var socket: SocketIOClient
//
//        private init() {
//            manager = SocketManager(socketURL: URL(string: "https://socket.******.**")!, config: [.log(true),.connectParams(["token":Utils.getToken()]),.reconnects(true)])
//            socket = manager.socket(forNamespace: "/**********")
//        }
//    }

    open static let instance = SocketService()
    
    //var instance = SocketService()
//    var manager : SocketManager
//    var socket : SocketIOClient
    
    private let manager : SocketManager
    private let socket : SocketIOClient
    
//    override init() {
//        super.init()
//    }
    
    init(){
        manager = SocketManager(socketURL: URL(string: BASE_URL)!,config: [.log(true), .compress])
        socket = SocketIOClient(manager: manager, nsp: "/swift")
    }
    
    // Create a socket for the /swift namespace
//    let manager = SocketManager(socketURL: URL(string: BASE_URL)!)
//    let defaultNamespaceSocket = instance.manager.defaultSocket
//    let socket = instance.manager.socket(forNamespace: "/swift")
    
    
    func establishConnection() {
        socket.connect()
    }
    
    func closeConnection() {
        socket.disconnect()
    }
    
    // Make a call to an API using socket
    func addChannel(channelName: String, channelDescription: String, completion: @escaping completionHandler) {
        socket.emit("newChannel", channelName, channelDescription)
        completion(true)
    }
    
    // The API returns an array, ack is for acknowledgement
    //This is listening on the socket for an event of type channelcreated
    func getChannel(completion: @escaping completionHandler) {
        socket.on("channelCreated") { (dataArray, ack) in
            guard let channelName = dataArray[0] as? String else { return }
            guard let channelDesc = dataArray[1] as? String else { return }
            guard let channelId = dataArray[2] as? String else { return }
            
            print(channelId)
            print(channelName)
            print(channelDesc)
            
            let newChannel = Channel(channelTitle: channelName, channelDescription: channelDesc, id: channelId)
            MessageService.instance.channels.append(newChannel)
            completion(true)
        }
    }
    
    func addMessage(messageBody: String, userId: String, channelId: String, complertion: @escaping completionHandler) {
        let user = UserDataService.instance
        socket.emit("newMessage", messageBody, userId, channelId, user.name, user.avatarName, user.avatarColor)
        complertion(true)
    }
}

